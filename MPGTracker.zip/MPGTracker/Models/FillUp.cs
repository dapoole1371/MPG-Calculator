﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace MPGTracker.Models
{
    public class FillUp
    {
        public int FillUpID { get; set; }
        public int VehicleID { get; set; }
        public double Gallons { get; set; }
        public double MilesDriven { get; set; }
        [DataType(DataType.Date)]
        public DateTime Date { get; set; }
        public Vehicle Vehicle { get; set; }
        [NotMapped]
        public double MPG
        {
            get
            {
                return MilesDriven / Gallons;
            }
        }
    }
}
