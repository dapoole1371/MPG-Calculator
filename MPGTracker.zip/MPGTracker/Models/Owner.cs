﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Threading.Tasks;

namespace MPGTracker.Models
{
    public class Owner
    {
        public int ID { get; set; }
        [DisplayName("First Name")]
        public string FirstName { get; set; }
        [DisplayName("Last Name")]
        public string LastName { get; set; }
        [DisplayName("Owner Name")]
        public string FullName
        {
            get
            {
                return FirstName + " " + LastName;
            }
        }
        public List<Vehicle> Vehicles { get; set; }
    }
}
