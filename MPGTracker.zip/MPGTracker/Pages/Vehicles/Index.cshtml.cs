﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Query;
using MPGTracker.Data;
using MPGTracker.Models;

namespace MPGTracker.Pages.Vehicles
{
    public class IndexModel : PageModel
    {
        private readonly MPGTracker.Data.MPGTrackerContext _context;

        public IndexModel(MPGTracker.Data.MPGTrackerContext context)
        {
            _context = context;
        }
        public string MakeSearch { get; set; }
        public DateTime? BeginDate { get; set; }
        public DateTime? EndDate { get; set; }
        public IList<Vehicle> Vehicle { get; set; }
        public IList<FillUp> FillUp { get; set; }
        public async Task OnGetAsync(string searchString, DateTime? beginDate, DateTime? endDate)
        {
            IQueryable<Vehicle> vehiclesIQ = from v in _context.Vehicles
                                             select v;

            MakeSearch = searchString;
            if (!String.IsNullOrEmpty(searchString))
            {
                vehiclesIQ = vehiclesIQ.Where(v => v.VehicleMake.Contains(searchString) ||
                                                   v.VehicleModel.Contains(searchString)) ;
            }
            IQueryable<FillUp> fillupsIQ = from f in _context.FillUps
                                           select f;

            BeginDate = beginDate;
            EndDate = endDate;
            
            Vehicle = await vehiclesIQ.AsNoTracking()
                .Include(v => v.Owner)
                .Include(f => f.FillUps)
                .ToListAsync();
            if (beginDate != null && endDate == null)
            {
                fillupsIQ = fillupsIQ.Where(f => f.Date >= beginDate);
                FillUp = await fillupsIQ.ToListAsync();
                foreach (var item in Vehicle)
                {
                    item.FillUps = FillUp;
                    item.MPG = item.FillUps.Sum(f => f.MilesDriven) / item.FillUps.Sum(f => f.Gallons);
                }
            }
            if (beginDate == null && endDate != null)
            {
                fillupsIQ = fillupsIQ.Where(f => f.Date <= endDate);
                FillUp = await fillupsIQ.ToListAsync();
                foreach (var item in Vehicle)
                {
                    item.FillUps = FillUp;
                    item.MPG = item.FillUps.Sum(f => f.MilesDriven) / item.FillUps.Sum(f => f.Gallons);
                }
            }
            if (beginDate != null && endDate != null)
            {
                fillupsIQ = fillupsIQ.Where(f => f.Date <= beginDate && f.Date >= beginDate);
                FillUp = await fillupsIQ.ToListAsync();
                foreach (var item in Vehicle)
                {
                    item.FillUps = FillUp;
                    item.MPG = item.FillUps.Sum(f => f.MilesDriven) / item.FillUps.Sum(f => f.Gallons);
                }
            }

            foreach (var item in Vehicle)
            {
                item.MPG = item.FillUps.Sum(f => f.MilesDriven) / item.FillUps.Sum(f => f.Gallons);
            }

        }
    }
}
