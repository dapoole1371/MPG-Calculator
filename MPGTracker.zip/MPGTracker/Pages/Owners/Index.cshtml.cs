﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using MPGTracker.Data;
using MPGTracker.Models;

namespace MPGTracker.Pages.Owners
{
    public class IndexModel : PageModel
    {
        private readonly MPGTracker.Data.MPGTrackerContext _context;

        public IndexModel(MPGTracker.Data.MPGTrackerContext context)
        {
            _context = context;
        }

        public string NameSort { get; set; }
        public string CurrentFilter { get; set; }
        public string CurrentSort { get; set; }
        public IList<Owner> Owners { get;set; }

        public async Task OnGetAsync(string sortOrder, string searchString)
        {
            NameSort = String.IsNullOrEmpty(sortOrder) ? "name_desc" : "";

            CurrentFilter = searchString;

            IQueryable<Owner> ownersIQ = from o in _context.Owners
                select o;
            if (!String.IsNullOrEmpty(searchString))
            {
                ownersIQ = ownersIQ.Where(o => o.LastName.Contains(searchString)
                                               || o.FirstName.Contains(searchString));
            }

            switch (sortOrder)
            {
                case "name_desc":
                    ownersIQ = ownersIQ.OrderByDescending(o => o.LastName);
                    break;
                default:
                    ownersIQ = ownersIQ.OrderBy(o => o.LastName);
                    break;
            }

            Owners = await ownersIQ.AsNoTracking().ToListAsync();
        }
    }
}
