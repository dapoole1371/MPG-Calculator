﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using MPGTracker.Data;
using MPGTracker.Models;

namespace MPGTracker.Pages.FillUps
{
    public class IndexModel : PageModel
    {
        private readonly MPGTracker.Data.MPGTrackerContext _context;

        public IndexModel(MPGTracker.Data.MPGTrackerContext context)
        {
            _context = context;
        }

        public IList<FillUp> FillUp { get;set; }

        public async Task OnGetAsync()
        {
            FillUp = await _context.FillUps
                .Include(f => f.Vehicle).ToListAsync();
        }
    }
}
