﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MPGTracker.Data;
using MPGTracker.Models;

namespace MPGTracker.Data
{
    public static class DbInitializer
    {
        public static void Initialize(MPGTrackerContext context)
        {
            context.Database.EnsureCreated();

            // Look for any students.
            if (context.Owners.Any())
            {
                return;   // DB has been seeded
            }

            var owners = new Owner[]
            {
                new Owner{FirstName = "Dave", LastName = "Poole"}
            };

            context.Owners.AddRange(owners);
            context.SaveChanges();
        }
    }
}
